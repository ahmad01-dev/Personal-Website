  let array = ["Python", "Java", "Numpy", "Pandas", "MySql", "MongoDb", "Csharp", "Asp.net", "Html", "Css", "Java script", "Node.js", "Flex box", "Bootstrap", "Jquery", "Ajax"]
  async function changeText(){
    count = 0;  
        while(count < array.length){
        document.getElementById('changingText').innerHTML = array[count];
        await new Promise(resolve => setTimeout(resolve, 1500));
        count++;
        if(count == array.length){
            count = 0;
        }
    }
  }
  changeText()
  function regexChecker(){
    let firstname = document.getElementById("firstName").value;
    let lastname = document.getElementById("lastName").value;
    let email = document.getElementById("email").value;
    let regexChecker = /^[A-Z][A-Za-z]+$/;
    let emailRegexChecker = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (firstname.match(regexChecker) && lastname.match(regexChecker) && email.match(emailRegexChecker)){
      document.getElementById("error").innerHTML = "";
      document.getElementById("firstName").value = "";
      document.getElementById("lastName").value = "";
      document.getElementById("email").value = "";
      alert("Your request was sent successfully!");
    } 
    else {
        document.getElementById("error").innerHTML = "First letter of first name and last name should be capitalized and more than 1 letter. Invalid email address.";
    }
}